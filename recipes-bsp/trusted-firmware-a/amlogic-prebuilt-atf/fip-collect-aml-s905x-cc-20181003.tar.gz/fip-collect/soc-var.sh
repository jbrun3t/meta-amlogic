export SOCFAMILY=gxl
